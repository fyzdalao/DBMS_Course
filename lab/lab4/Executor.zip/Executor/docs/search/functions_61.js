var searchData=
[
  ['allocatepage',['allocatePage',['../classbadgerdb_1_1_file.html#a7d0e047bcc8dc4cee36aac5b2060bbe3',1,'badgerdb::File']]],
  ['allocpage',['allocPage',['../classbadgerdb_1_1_buf_mgr.html#ab9ae3b12aac55b119b5763e3de2a4d2b',1,'badgerdb::BufMgr']]]
];
